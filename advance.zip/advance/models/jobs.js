const db=require("../config/db")
class jobMosel{






static async getjob(){



    return new Promise (resolve =>{


        db.query("select * from jobs" ,[] ,(error , result)=>{
if(!error)
resolve(result)
        })
    })



}


static async addjob(jname,jaddress,jsalary)
{
return new Promise(resolve=>{
db.query("insert into jobs(jname,jaddress,jsalary) values(?,?,?)",[jname,jaddress,jsalary],(e,r)=>{
    if(!e)
    resolve(true)
    else
    resolve(false)
})      
})
}
static async deletejob(id)
{
    return new Promise(resolve=>{
    db.query("delete from jobs where id=?",[id],(e,r)=>{
        if(e)
        resolve(false)
        else
        resolve(true)
    })      
    })

}

static async edit(id,jname,jaddress,jsalary){
    return new Promise(resolve=>{
        db.query("update jobs set jname=? , jaddress=? ,jsalary=?  where id=?",[id,jname,jaddress,jsalary],(e,r)=>{
            if(!e)
            resolve(r)
           
        })      
        })  
}
}

module.exports=jobMosel