const express = require('express');
const mydb=require('./config/db');
const app = express();
const rout=require("./routes/router")

app.use(rout)

app.get('/', (req, res,next) => {
  res.send("fadi")
});

app.listen(3003, () => console.log('Server started on port 3003'));

