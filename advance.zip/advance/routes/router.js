const express=require('express')
const jobController=require("../Controllers/jobController")
const router=require('express').Router();




router.get("/",(req,res,next)=>{
    res.send("fadi");
})


router.get("/alljobs",jobController.getalljob)
router.post("/addjob",jobController.addnewjob)
router.post("/deletejob",jobController.deletejob)
router.post("/editjob",jobController.updatejob)

module.exports=router