const jobModel=require("../models/jobs")

class jobController{


    static async getalljob(req,res)
    {   
       var results= await jobModel.getjob();

       if(results)
        res.send(results)

    }


    static async addnewjob(req,res)
    {
     
var x =await jobModel.addjob(req.body.jname,req.body.jaddress,req.body.jsalary)
    if(x==true)
    res.send("add successfully")
    else
    res.send("add job falled")
}

  




static async deletejob(req,res)
{
 const id=req.body.id;
 if(id)
 {
    var result =await jobModel.deletejob(req.body.id)
 }

if(x==true)
res.send("add successfully")
else
res.send("add falled")
}

static async updatejob(req,res)
{
 const id=req.body.id;
 var x =await jobModel.edit(id,req.body.jname,req.body.jaddress,req.body.jsalary)

if(x==true)
res.send("updatejob successfully")
else
res.send("updatejob falled")
}
}

module.exports=jobController